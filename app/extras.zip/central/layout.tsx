import type React from "react"
import { TeacherLayout } from "@/components/teacher-layout"

export default function CentralLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <TeacherLayout>{children}</TeacherLayout>
}
