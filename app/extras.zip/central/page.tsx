"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { FilterSelector } from "@/components/filter-selector"
import { CentralizacionTable } from "@/components/central/centralizacion-table"

interface FilterState {
  colegioId?: number
  nivelId?: number
  cursoId?: number
  paraleloId?: number
  trimestreId?: number
}

export default function CentralPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [filters, setFilters] = useState<FilterState>({})
  const [isLoading, setIsLoading] = useState(false)

  const handleFilterChange = (newFilters: FilterState) => {
    setFilters(newFilters)
  }

  const allFiltersSelected = () => {
    return (
      filters.colegioId !== undefined &&
      filters.nivelId !== undefined &&
      filters.cursoId !== undefined &&
      filters.paraleloId !== undefined &&
      filters.trimestreId !== undefined
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Centralización de Notas</h1>
        <p className="text-muted-foreground">Gestione las notas centralizadas de los estudiantes.</p>
      </div>

      <FilterSelector onFilterChange={handleFilterChange} showMateria={false} />

      {allFiltersSelected() ? (
        <Card>
          <CardHeader>
            <CardTitle>Notas Centralizadas</CardTitle>
            <CardDescription>Notas de todas las materias para el curso seleccionado.</CardDescription>
          </CardHeader>
          <CardContent>
            <CentralizacionTable
              colegioId={filters.colegioId!}
              nivelId={filters.nivelId!}
              cursoId={filters.cursoId!}
              paraleloId={filters.paraleloId!}
              trimestre={filters.trimestreId!}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-10">
            <div className="text-center text-muted-foreground">
              Seleccione todos los filtros para ver las notas centralizadas.
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
