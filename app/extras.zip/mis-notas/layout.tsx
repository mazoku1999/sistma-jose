import type React from "react"
import { TeacherLayout } from "@/components/teacher-layout"

export default function MisNotasLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <TeacherLayout>{children}</TeacherLayout>
}
