"use client"

import { useState, useEffect } from "react"
import { useParams, useSearchParams, useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Users, Clock, ClipboardList, FileText, ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"
import NotasTab from "@/components/aula/notas-tab"
import { AsistenciasTab } from "@/components/aula/asistencias-tab"
import { SituacionTab } from "@/components/aula/situacion-tab"

interface Aula {
  id: number
  nombre_aula: string
  colegio: string
  nivel: string
  curso: string
  paralelo: string
  materia: string
  estudiantes: number
  max_estudiantes: number
}

export default function AulaPage() {
  const params = useParams<{ id: string }>()
  const router = useRouter()
  const searchParams = useSearchParams()
  const tabParam = searchParams.get("tab")
  const [aula, setAula] = useState<Aula | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState(tabParam || "notas")

  useEffect(() => {
    if (!params.id) {
      router.push('/aulas')
      return
    }
    fetchAula()
  }, [params.id, router])

  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  const fetchAula = async () => {
    if (!params.id) return

    setIsLoading(true)
    try {
      const response = await fetch(`/api/aulas/${params.id}`)
      if (response.ok) {
        const data = await response.json()
        setAula(data)
      } else {
        console.error("Error al cargar aula")
      }
    } catch (error) {
      console.error("Error al cargar aula:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
          <p className="mt-4 text-muted-foreground">Cargando información del aula...</p>
        </div>
      </div>
    )
  }

  if (!aula) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground mb-3 opacity-50" />
          <h3 className="font-medium mb-1">Aula no encontrada</h3>
          <p className="text-sm text-muted-foreground mb-4">El aula solicitada no existe o no tienes acceso a ella</p>
          <Button asChild>
            <Link href="/aulas">Volver a mis aulas</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/aulas">
                <ArrowLeft className="h-4 w-4" />
              </Link>
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">{aula.nombre_aula}</h1>
          </div>
          <p className="text-muted-foreground">
            {aula.curso} {aula.paralelo} - {aula.materia} - {aula.colegio}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href={`/aulas/${params.id}/estudiantes`}>
              <Users className="mr-2 h-4 w-4" />
              Estudiantes
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href={`/aulas/${params.id}/reportes`}>
              <FileText className="mr-2 h-4 w-4" />
              Reportes
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Estudiantes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{aula.estudiantes}</div>
            <p className="text-xs text-muted-foreground">
              {aula.max_estudiantes - aula.estudiantes} cupos disponibles de {aula.max_estudiantes}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Asistencias</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">--</div>
            <p className="text-xs text-muted-foreground">Registros de asistencia</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Notas</CardTitle>
            <ClipboardList className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">--</div>
            <p className="text-xs text-muted-foreground">Promedio del aula</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-3 md:w-[400px]">
          <TabsTrigger value="notas">Notas</TabsTrigger>
          <TabsTrigger value="asistencias">Asistencias</TabsTrigger>
          <TabsTrigger value="situacion">Situación</TabsTrigger>
        </TabsList>
        <TabsContent value="notas">
          <NotasTab aulaId={aula.id} />
        </TabsContent>
        <TabsContent value="asistencias">
          <AsistenciasTab aulaId={aula.id} />
        </TabsContent>
        <TabsContent value="situacion">
          <SituacionTab aulaId={aula.id} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
