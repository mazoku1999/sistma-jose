"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Plus, Trash } from "lucide-react"

interface Aula {
  id: number
  nombre_aula: string
}

interface HorarioItem {
  id: number
  dia: number
  hora_inicio: string
  hora_fin: string
  id_aula_profesor: number
  nombre_aula: string
}

const diasSemana = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]

export default function HorarioPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [aulas, setAulas] = useState<Aula[]>([])
  const [horario, setHorario] = useState<HorarioItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [newHorario, setNewHorario] = useState({
    dia: "1",
    hora_inicio: "08:00",
    hora_fin: "09:00",
    id_aula_profesor: "",
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setIsLoading(true)
    try {
      // Fetch aulas
      const aulasResponse = await fetch("/api/aulas")
      if (aulasResponse.ok) {
        const aulasData = await aulasResponse.json()
        setAulas(aulasData)
      }

      // Fetch horario
      const horarioResponse = await fetch("/api/horario")
      if (horarioResponse.ok) {
        const horarioData = await horarioResponse.json()
        setHorario(horarioData)
      }
    } catch (error) {
      console.error("Error fetching data:", error)
      toast({
        title: "Error",
        description: "Error al cargar los datos",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddHorario = async () => {
    if (!newHorario.dia || !newHorario.hora_inicio || !newHorario.hora_fin || !newHorario.id_aula_profesor) {
      toast({
        title: "Error",
        description: "Todos los campos son requeridos",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    try {
      const response = await fetch("/api/horario", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          dia: Number.parseInt(newHorario.dia),
          hora_inicio: newHorario.hora_inicio,
          hora_fin: newHorario.hora_fin,
          id_aula_profesor: Number.parseInt(newHorario.id_aula_profesor),
        }),
      })

      if (response.ok) {
        toast({
          title: "Éxito",
          description: "Horario agregado correctamente",
        })
        setNewHorario({
          dia: "1",
          hora_inicio: "08:00",
          hora_fin: "09:00",
          id_aula_profesor: "",
        })
        setIsDialogOpen(false)
        fetchData()
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Error al agregar el horario",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error adding horario:", error)
      toast({
        title: "Error",
        description: "Error al agregar el horario",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteHorario = async (id: number) => {
    if (!confirm("¿Está seguro de eliminar este horario?")) {
      return
    }

    try {
      const response = await fetch(`/api/horario/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "Éxito",
          description: "Horario eliminado correctamente",
        })
        fetchData()
      } else {
        const error = await response.json()
        toast({
          title: "Error",
          description: error.error || "Error al eliminar el horario",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error deleting horario:", error)
      toast({
        title: "Error",
        description: "Error al eliminar el horario",
        variant: "destructive",
      })
    }
  }

  // Group horario by day
  const horarioPorDia: { [key: number]: HorarioItem[] } = {}
  horario.forEach((item) => {
    if (!horarioPorDia[item.dia]) {
      horarioPorDia[item.dia] = []
    }
    horarioPorDia[item.dia].push(item)
  })

  // Sort horario by hora_inicio
  Object.keys(horarioPorDia).forEach((dia) => {
    horarioPorDia[Number.parseInt(dia)].sort((a, b) => a.hora_inicio.localeCompare(b.hora_inicio))
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Mi Horario</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Agregar Horario
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Agregar Nuevo Horario</DialogTitle>
              <DialogDescription>Complete los datos para agregar un nuevo horario.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="dia">Día</Label>
                <Select value={newHorario.dia} onValueChange={(value) => setNewHorario({ ...newHorario, dia: value })}>
                  <SelectTrigger id="dia">
                    <SelectValue placeholder="Seleccionar día" />
                  </SelectTrigger>
                  <SelectContent>
                    {diasSemana.map((dia, index) => (
                      <SelectItem key={index} value={(index + 1).toString()}>
                        {dia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="hora-inicio">Hora Inicio</Label>
                  <Input
                    id="hora-inicio"
                    type="time"
                    value={newHorario.hora_inicio}
                    onChange={(e) =>
                      setNewHorario({
                        ...newHorario,
                        hora_inicio: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hora-fin">Hora Fin</Label>
                  <Input
                    id="hora-fin"
                    type="time"
                    value={newHorario.hora_fin}
                    onChange={(e) => setNewHorario({ ...newHorario, hora_fin: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="aula">Aula</Label>
                <Select
                  value={newHorario.id_aula_profesor}
                  onValueChange={(value) => setNewHorario({ ...newHorario, id_aula_profesor: value })}
                >
                  <SelectTrigger id="aula">
                    <SelectValue placeholder="Seleccionar aula" />
                  </SelectTrigger>
                  <SelectContent>
                    {aulas.map((aula) => (
                      <SelectItem key={aula.id} value={aula.id.toString()}>
                        {aula.nombre_aula}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleAddHorario} disabled={isSaving}>
                {isSaving ? "Guardando..." : "Guardar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {diasSemana.slice(0, 5).map((dia, index) => (
          <Card key={index} className="h-full">
            <CardHeader className="bg-gray-50">
              <CardTitle>{dia}</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {isLoading ? (
                <div className="flex justify-center py-4">
                  <p>Cargando...</p>
                </div>
              ) : horarioPorDia[index + 1] && horarioPorDia[index + 1].length > 0 ? (
                <div className="space-y-3">
                  {horarioPorDia[index + 1].map((item) => (
                    <div key={item.id} className="p-3 bg-blue-50 rounded-md relative">
                      <div className="font-medium">{item.nombre_aula}</div>
                      <div className="text-sm text-gray-500">
                        {item.hora_inicio} - {item.hora_fin}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 h-6 w-6"
                        onClick={() => handleDeleteHorario(item.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500">No hay clases</div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
